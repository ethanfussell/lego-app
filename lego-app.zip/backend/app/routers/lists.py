# backend/app/routers/lists.py
from __future__ import annotations

from typing import Any, Dict, List as TypingList, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session, selectinload

from ..core.auth import get_current_user, get_current_user_optional
from ..db import get_db
from ..models import List as ListModel, ListItem as ListItemModel, Set as SetModel, User as UserModel
from ..schemas.list import (
    ListCreate,
    ListDetail,
    ListItemCreate,
    ListOrderUpdate,
    ListSummary,
    ListUpdate,
)

router = APIRouter(prefix="/lists", tags=["lists"])


# ---------------- helpers ----------------
def _resolve_set_num(db: Session, set_num_or_plain: str) -> str:
    """
    Accepts '10305' or '10305-1' and returns canonical set_num in DB ('10305-1').
    """
    raw = (set_num_or_plain or "").strip()
    if not raw:
        raise HTTPException(status_code=422, detail="set_num_required")

    plain = raw.split("-")[0].lower()
    plain_expr = func.split_part(SetModel.set_num, "-", 1)

    canonical = db.execute(
        select(SetModel.set_num)
        .where(func.lower(SetModel.set_num) == raw.lower())
        .limit(1)
    ).scalar_one_or_none()

    if not canonical:
        canonical = db.execute(
            select(SetModel.set_num)
            .where(func.lower(plain_expr) == plain)
            .limit(1)
        ).scalar_one_or_none()

    if not canonical:
        raise HTTPException(status_code=404, detail="set_not_found")

    return canonical


def _owner_username(db: Session, owner_id: int) -> str:
    return db.execute(
        select(UserModel.username).where(UserModel.id == int(owner_id))
    ).scalar_one()


def _summary_dict(lst: ListModel, owner_username: str) -> Dict[str, Any]:
    items_count = len(lst.items) if lst.items is not None else 0
    return {
        "id": int(lst.id),
        "title": lst.title,
        "description": lst.description,
        "is_public": bool(lst.is_public),
        "owner": owner_username,
        "items_count": int(items_count),
        "position": int(lst.position or 0),
        "is_system": bool(getattr(lst, "is_system", False)),
        "system_key": getattr(lst, "system_key", None),
        "created_at": lst.created_at,
        "updated_at": lst.updated_at,
    }


def _detail_dict(lst: ListModel, owner_username: str) -> Dict[str, Any]:
    base = _summary_dict(lst, owner_username)
    base["items"] = [li.set_num for li in (lst.items or [])]
    return base


def _require_owner_or_403(lst: ListModel, current_user: UserModel) -> None:
    if int(lst.owner_id) != int(current_user.id):
        raise HTTPException(status_code=403, detail="not_owner")


def _get_list_visible_or_404(
    db: Session,
    list_id: int,
    current_user: Optional[UserModel],
    *,
    load_items: bool = False,
) -> ListModel:
    """
    ✅ INVISIBILITY RULE:
    - If list does not exist -> 404
    - If list is private and user is not the owner (or logged out) -> 404
    - If list is public -> visible to anyone
    """
    q = select(ListModel).where(ListModel.id == int(list_id))
    if load_items:
        q = q.options(selectinload(ListModel.items))

    lst = db.execute(q).scalar_one_or_none()
    if not lst:
        raise HTTPException(status_code=404, detail="list_not_found")

    if not bool(lst.is_public):
        if current_user is None or int(lst.owner_id) != int(current_user.id):
            # hide existence
            raise HTTPException(status_code=404, detail="list_not_found")

    return lst


# ---------------- Public lists ----------------
@router.get("/public", response_model=TypingList[ListSummary])
def api_get_public_lists(db: Session = Depends(get_db)) -> TypingList[ListSummary]:
    rows = db.execute(
        select(ListModel, UserModel.username)
        .join(UserModel, UserModel.id == ListModel.owner_id)
        .where(ListModel.is_public.is_(True))
        .order_by(UserModel.username.asc(), ListModel.position.asc(), ListModel.id.asc())
    ).all()

    return [_summary_dict(lst, username) for (lst, username) in rows]


# ---------------- My lists (auth required) ----------------
@router.get("/me", response_model=TypingList[ListSummary])
def api_get_my_lists(
    include_system: bool = Query(default=True),  # kept for backward compat; currently ignored
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> TypingList[ListSummary]:
    rows = db.execute(
        select(ListModel, UserModel.username)
        .join(UserModel, UserModel.id == ListModel.owner_id)
        .where(ListModel.owner_id == current_user.id)
        .order_by(ListModel.position.asc(), ListModel.id.asc())
    ).all()

    return [_summary_dict(lst, username) for (lst, username) in rows]


# ---------------- Reorder my lists (auth required) ----------------
@router.put("/me/order", response_model=TypingList[ListDetail])
def api_reorder_my_lists(
    payload: ListOrderUpdate,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> TypingList[ListDetail]:
    ordered_ids = [int(x) for x in (payload.ordered_ids or [])]

    mine = db.execute(
        select(ListModel)
        .where(ListModel.owner_id == current_user.id)
        .order_by(ListModel.position.asc(), ListModel.id.asc())
    ).scalars().all()

    mine_custom_ids = [int(l.id) for l in mine if not bool(getattr(l, "is_system", False))]

    if sorted(ordered_ids) != sorted(mine_custom_ids):
        raise HTTPException(status_code=400, detail="ordered_ids_must_match_all_custom")

    by_id = {int(l.id): l for l in mine}
    for pos, lid in enumerate(ordered_ids):
        by_id[int(lid)].position = int(pos)

    db.commit()

    updated = db.execute(
        select(ListModel).options(selectinload(ListModel.items))
        .where(ListModel.owner_id == current_user.id)
        .order_by(ListModel.position.asc(), ListModel.id.asc())
    ).scalars().all()

    return [_detail_dict(lst, current_user.username) for lst in updated]


# ---------------- Single list detail ----------------
@router.get("/{list_id}", response_model=ListDetail)
def api_get_list_detail(
    list_id: int,
    db: Session = Depends(get_db),
    current_user: Optional[UserModel] = Depends(get_current_user_optional),
) -> ListDetail:
    # ✅ this enforces invisibility for private lists
    lst = _get_list_visible_or_404(db, list_id, current_user, load_items=True)
    owner_username = _owner_username(db, int(lst.owner_id))
    return _detail_dict(lst, owner_username)


# ---------------- Create list (auth required) ----------------
@router.post("", response_model=ListDetail, status_code=status.HTTP_201_CREATED)
def api_create_list(
    payload: ListCreate,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> ListDetail:
    title = (payload.title or "").strip()
    if not title:
        raise HTTPException(status_code=422, detail="title_required")

    max_pos = db.execute(
        select(func.coalesce(func.max(ListModel.position), -1))
        .where(ListModel.owner_id == current_user.id)
    ).scalar_one()

    new_list = ListModel(
        owner_id=current_user.id,
        title=title,
        description=(payload.description.strip() if payload.description else None),
        is_public=bool(payload.is_public),
        position=int(max_pos) + 1,
        is_system=False,
        system_key=None,
    )
    db.add(new_list)
    db.commit()
    db.refresh(new_list)

    # no items yet
    return _detail_dict(new_list, current_user.username)


# ---------------- Add item (auth required) ----------------
@router.post("/{list_id}/items", status_code=status.HTTP_201_CREATED)
def api_add_list_item(
    list_id: int,
    payload: ListItemCreate,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    # ✅ private lists are invisible to non-owners (404)
    lst = _get_list_visible_or_404(db, list_id, current_user, load_items=False)

    # For public lists, you can keep 403 for non-owner writes
    _require_owner_or_403(lst, current_user)

    canonical = _resolve_set_num(db, payload.set_num)

    db.add(ListItemModel(list_id=lst.id, set_num=canonical))
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="set_already_in_list")

    return {"ok": True}


# ---------------- Remove item (auth required) ----------------
@router.delete("/{list_id}/items/{set_num}", status_code=status.HTTP_200_OK)
def api_remove_list_item(
    list_id: int,
    set_num: str,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    # ✅ private lists are invisible to non-owners (404)
    lst = _get_list_visible_or_404(db, list_id, current_user, load_items=False)
    _require_owner_or_403(lst, current_user)

    try:
        canonical = _resolve_set_num(db, set_num)
    except HTTPException as e:
        if e.status_code == 404 and e.detail == "set_not_found":
            raise HTTPException(status_code=404, detail="set_not_in_list")
        raise

    deleted = (
        db.query(ListItemModel)
        .filter(ListItemModel.list_id == lst.id, ListItemModel.set_num == canonical)
        .delete(synchronize_session=False)
    )
    db.commit()

    if int(deleted) == 0:
        raise HTTPException(status_code=404, detail="set_not_in_list")

    return {"ok": True}


# ---------------- Update list (auth required) ----------------
@router.patch("/{list_id}", response_model=ListDetail)
def api_update_list(
    list_id: int,
    payload: ListUpdate,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> ListDetail:
    # ✅ private lists are invisible to non-owners (404)
    lst = _get_list_visible_or_404(db, list_id, current_user, load_items=True)
    _require_owner_or_403(lst, current_user)

    if bool(getattr(lst, "is_system", False)):
        raise HTTPException(status_code=400, detail="cannot_update_system_list")

    if payload.title is not None:
        title = (payload.title or "").strip()
        if not title:
            raise HTTPException(status_code=422, detail="title_required")
        lst.title = title

    if payload.description is not None:
        lst.description = (payload.description or "").strip() or None

    if payload.is_public is not None:
        lst.is_public = bool(payload.is_public)

    db.add(lst)
    db.commit()
    db.refresh(lst)

    return _detail_dict(lst, current_user.username)


# ---------------- Delete list (auth required) ----------------
@router.delete("/{list_id}", status_code=status.HTTP_200_OK)
def api_delete_list(
    list_id: int,
    current_user: UserModel = Depends(get_current_user),
    db: Session = Depends(get_db),
) -> Dict[str, Any]:
    # ✅ private lists are invisible to non-owners (404)
    lst = _get_list_visible_or_404(db, list_id, current_user, load_items=False)
    _require_owner_or_403(lst, current_user)

    if bool(getattr(lst, "is_system", False)):
        raise HTTPException(status_code=400, detail="cannot_delete_system_list")

    db.delete(lst)
    db.commit()
    return {"ok": True}