# backend/app/routers/custom_collections.py
from __future__ import annotations

from datetime import datetime
from typing import List

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from ..core.auth import User, get_current_user
from ..db import get_db
from ..models import Collection, Set, User as UserModel
from ..schemas.collection import CollectionCreate, CollectionItem

router = APIRouter()

# ----------------------
# helpers
# ----------------------

def _require_set_exists(db: Session, set_num: str) -> None:
    exists = db.query(Set.set_num).filter(Set.set_num == set_num).first()
    if not exists:
        raise HTTPException(status_code=404, detail="Set not found")


def _get_user_id_by_username(db: Session, username: str) -> int:
    u = db.query(UserModel.id).filter(UserModel.username == username).first()
    if not u:
        raise HTTPException(status_code=404, detail="User not found")
    return int(u[0])


def _already_in(db: Session, user_id: int, set_num: str, type_: str) -> bool:
    row = (
        db.query(Collection)
        .filter(
            Collection.user_id == user_id,
            Collection.set_num == set_num,
            Collection.type == type_,
        )
        .first()
    )
    return row is not None


def _remove_if_present(db: Session, user_id: int, set_num: str, type_: str) -> bool:
    row = (
        db.query(Collection)
        .filter(
            Collection.user_id == user_id,
            Collection.set_num == set_num,
            Collection.type == type_,
        )
        .first()
    )
    if not row:
        return False
    db.delete(row)
    return True


def _as_item(username: str, set_num: str, type_: str, created_at: datetime) -> dict:
    # matches your old response shape + CollectionItem schema
    return {
        "username": username,
        "set_num": set_num,
        "type": type_,
        "created_at": created_at,
    }


# ----------------------
# Owned
# ----------------------

@router.post("/owned", status_code=status.HTTP_201_CREATED, response_model=CollectionItem)
def add_owned(
    payload: CollectionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    username = current_user.username
    user_id = int(current_user.id) if getattr(current_user, "id", None) is not None else None
    if user_id is None:
        # fallback if your auth User object doesn't include id yet
        user_id = _get_user_id_by_username(db, username)

    _require_set_exists(db, payload.set_num)

    if _already_in(db, user_id, payload.set_num, "owned"):
        raise HTTPException(status_code=400, detail="Already in owned")

    # create owned
    row = Collection(user_id=user_id, set_num=payload.set_num, type="owned")
    db.add(row)

    # if it was in wishlist, remove it
    _remove_if_present(db, user_id, payload.set_num, "wishlist")

    db.commit()
    db.refresh(row)

    return _as_item(username, row.set_num, row.type, row.created_at)


@router.delete("/owned/{set_num}", status_code=status.HTTP_204_NO_CONTENT)
def remove_owned(
    set_num: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    username = current_user.username
    user_id = int(current_user.id) if getattr(current_user, "id", None) is not None else None
    if user_id is None:
        user_id = _get_user_id_by_username(db, username)

    removed = _remove_if_present(db, user_id, set_num, "owned")
    if not removed:
        raise HTTPException(status_code=404, detail="Not in owned")

    db.commit()
    return


# ----------------------
# Wishlist
# ----------------------

@router.post("/wishlist", status_code=status.HTTP_201_CREATED, response_model=CollectionItem)
def add_wishlist(
    payload: CollectionCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    username = current_user.username
    user_id = int(current_user.id) if getattr(current_user, "id", None) is not None else None
    if user_id is None:
        user_id = _get_user_id_by_username(db, username)

    _require_set_exists(db, payload.set_num)

    if _already_in(db, user_id, payload.set_num, "wishlist"):
        raise HTTPException(status_code=400, detail="Already in wishlist")

    row = Collection(user_id=user_id, set_num=payload.set_num, type="wishlist")
    db.add(row)

    db.commit()
    db.refresh(row)

    return _as_item(username, row.set_num, row.type, row.created_at)


@router.delete("/wishlist/{set_num}", status_code=status.HTTP_204_NO_CONTENT)
def remove_wishlist(
    set_num: str,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    username = current_user.username
    user_id = int(current_user.id) if getattr(current_user, "id", None) is not None else None
    if user_id is None:
        user_id = _get_user_id_by_username(db, username)

    removed = _remove_if_present(db, user_id, set_num, "wishlist")
    if not removed:
        raise HTTPException(status_code=404, detail="Not in wishlist")

    db.commit()
    return


# ----------------------
# Public reads
# ----------------------

@router.get("/users/{username}/owned", response_model=List[CollectionItem])
def list_owned(username: str, db: Session = Depends(get_db)):
    user_id = _get_user_id_by_username(db, username)
    rows = (
        db.query(Collection)
        .filter(Collection.user_id == user_id, Collection.type == "owned")
        .order_by(Collection.created_at.desc())
        .all()
    )
    return [_as_item(username, r.set_num, r.type, r.created_at) for r in rows]


@router.get("/users/{username}/wishlist", response_model=List[CollectionItem])
def list_wishlist(username: str, db: Session = Depends(get_db)):
    user_id = _get_user_id_by_username(db, username)
    rows = (
        db.query(Collection)
        .filter(Collection.user_id == user_id, Collection.type == "wishlist")
        .order_by(Collection.created_at.desc())
        .all()
    )
    return [_as_item(username, r.set_num, r.type, r.created_at) for r in rows]


# ----------------------
# "Me" reads
# ----------------------

@router.get("/me/owned", response_model=List[CollectionItem])
def list_my_owned(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    username = current_user.username
    user_id = int(current_user.id) if getattr(current_user, "id", None) is not None else None
    if user_id is None:
        user_id = _get_user_id_by_username(db, username)

    rows = (
        db.query(Collection)
        .filter(Collection.user_id == user_id, Collection.type == "owned")
        .order_by(Collection.created_at.desc())
        .all()
    )
    return [_as_item(username, r.set_num, r.type, r.created_at) for r in rows]


@router.get("/me/wishlist", response_model=List[CollectionItem])
def list_my_wishlist(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    username = current_user.username
    user_id = int(current_user.id) if getattr(current_user, "id", None) is not None else None
    if user_id is None:
        user_id = _get_user_id_by_username(db, username)

    rows = (
        db.query(Collection)
        .filter(Collection.user_id == user_id, Collection.type == "wishlist")
        .order_by(Collection.created_at.desc())
        .all()
    )
    return [_as_item(username, r.set_num, r.type, r.created_at) for r in rows]