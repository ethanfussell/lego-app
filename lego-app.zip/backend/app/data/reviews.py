# app/data/reviews.py
from typing import List, Dict, Any

REVIEWS: List[Dict[str, Any]] = []